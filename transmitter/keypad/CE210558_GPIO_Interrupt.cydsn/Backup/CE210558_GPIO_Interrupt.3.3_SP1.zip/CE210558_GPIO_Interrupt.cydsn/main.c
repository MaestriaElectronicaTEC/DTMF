/*****************************************************************************
* File Name: main.c
*
* Version: 1.0
*
* Description:
* In this project, custom ISR is created for the GPIO interrupt. The file -  
* "InterruptRoutine.c" contains user ISR for the interrupt. Pin P0[0] is  
* configured with rising edge interrupt and P0[1] is configured with falling 
* edge interrupt. In the ISR, Logic 0  is written at LED pin (port P0[2]) on 
* the rising edge interrupt and Logic 1 is written on falling edge interrupt. 
* For testing purposes, both the interrupt pins - P0[0] and P0[1] can be shorted 
* externally and driven with the same signal.
*
* Related Document: Code example CE210558
*
* Hardware Dependency: See code example CE210558
*
******************************************************************************
* Copyright (2015), Cypress Semiconductor Corporation.
******************************************************************************
* This software is owned by Cypress Semiconductor Corporation (Cypress) and is
* protected by and subject to worldwide patent protection (United States and
* foreign), United States copyright laws and international treaty provisions.
* Cypress hereby grants to licensee a personal, non-exclusive, non-transferable
* license to copy, use, modify, create derivative works of, and compile the
* Cypress Source Code and derivative works for the sole purpose of creating
* custom software in support of licensee product to be used only in conjunction
* with a Cypress integrated circuit as specified in the applicable agreement.
* Any reproduction, modification, translation, compilation, or representation of
* this software except as specified above is prohibited without the express
* written permission of Cypress.
*
* Disclaimer: CYPRESS MAKES NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, WITH
* REGARD TO THIS MATERIAL, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
* Cypress reserves the right to make changes without further notice to the
* materials described herein. Cypress does not assume any liability arising out
* of the application or use of any product or circuit described herein. Cypress
* does not authorize its products for use as critical components in life-support
* systems where a malfunction or failure may reasonably be expected to result in
* significant injury to the user. The inclusion of Cypress' product in a life-
* support systems application implies that the manufacturer assumes all risk of
* such use and in doing so indemnifies Cypress against all charges. Use may be
* limited by and subject to the applicable Cypress software license agreement.
*****************************************************************************/

#include <device.h>
#include "InterruptRoutine.h"

CY_ISR_PROTO(GPIO_ISR);

int main()
{	
    /* Initialize the custom defined ISR */
	/* GPIO_ISR is written in InterruptRoutine.c file */
    isr_Pins_StartEx(GPIO_ISR);

	/* Enable global interrupt */
    CyGlobalIntEnable; 

    for(;;)
    {
		/* wait here */
		/* LED connected at P0[2] is controlled by the code in GPIO_ISR */
    }
}

/* [] END OF FILE */
